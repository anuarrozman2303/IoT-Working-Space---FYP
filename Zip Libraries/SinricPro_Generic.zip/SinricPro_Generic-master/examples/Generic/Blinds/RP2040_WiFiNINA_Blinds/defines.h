/****************************************************************************************************************************
  defines.h
  For nRF52 boards, running WiFiNINA shield

  Based on and modified from SinricPro libarary (https://github.com/sinricpro/)
  to support other boards such as  SAMD21, SAMD51, Adafruit's nRF52 boards, etc.

  Built by Khoi Hoang https://github.com/khoih-prog/SinricPro_Generic
  Licensed under MIT license
 **********************************************************************************************************************************/

#ifndef defines_h
#define defines_h

#define SINRIC_PRO_USING_WIFININA       true

#define WEBSOCKETS_NETWORK_TYPE         NETWORK_WIFININA

#define SRP_DEBUG_PORT                Serial

// Debug Level from 0 to 4
#define _SRP_LOGLEVEL_                3

// Uncomment the following line to enable serial debug output
#define ENABLE_DEBUG    true

#if ENABLE_DEBUG
  #define DEBUG_PORT Serial
  #define NODEBUG_WEBSOCKETS
  #define NDEBUG
#endif

#if ( defined(ARDUINO_NANO_RP2040_CONNECT) || defined(ARDUINO_ARCH_RP2040) || defined(ARDUINO_RASPBERRY_PI_PICO) || \
      defined(ARDUINO_GENERIC_RP2040) || defined(ARDUINO_ADAFRUIT_FEATHER_RP2040) )

#warning RASPBERRY_PI_PICO board selected

#if defined(ARDUINO_ARCH_MBED)

#warning Using ARDUINO_ARCH_MBED

#if ( defined(ARDUINO_NANO_RP2040_CONNECT)    || defined(ARDUINO_RASPBERRY_PI_PICO) || \
          defined(ARDUINO_GENERIC_RP2040) || defined(ARDUINO_ADAFRUIT_FEATHER_RP2040) )
// Only undef known BOARD_NAME to use better one
#undef BOARD_NAME
#endif

#if defined(ARDUINO_RASPBERRY_PI_PICO)
  #define BOARD_NAME      "MBED RASPBERRY_PI_PICO"
#elif defined(ARDUINO_ADAFRUIT_FEATHER_RP2040)
  #define BOARD_NAME      "MBED ADAFRUIT_FEATHER_RP2040"
#elif defined(ARDUINO_GENERIC_RP2040)
  #define BOARD_NAME      "MBED GENERIC_RP2040"
#elif defined(ARDUINO_NANO_RP2040_CONNECT)
  #define BOARD_NAME      "MBED NANO_RP2040_CONNECT"
#else
  // Use default BOARD_NAME if exists
  #if !defined(BOARD_NAME)
    #define BOARD_NAME      "MBED Unknown RP2040"
  #endif
#endif

#endif

#else

#error This code is intended to run only on the RP2040-based boards ! Please check your Tools->Board setting

#endif

#include "WiFiNINA_Generic.h"

// Select the IP address according to your local network
IPAddress ip(192, 168, 2, 222);

#define WIFI_SSID         "YOUR-WIFI-SSID"
#define WIFI_PASS         "YOUR-WIFI-PASSWORD"

#define APP_KEY           "YOUR-APP-KEY"      // Should look like "de0bxxxx-1x3x-4x3x-ax2x-5dabxxxxxxxx"
#define APP_SECRET        "YOUR-APP-SECRET"   // Should look like "5f36xxxx-x3x7-4x3x-xexe-e86724a9xxxx-4c4axxxx-3x3x-x5xe-x9x3-333d65xxxxxx"

#define BLINDS_ID         "YOUR-DEVICE-ID"    // Should look like "5dc1564130xxxxxxxxxxxxxx"

#define BAUD_RATE         115200              // Change baudrate to your need

#endif    //defines_h
